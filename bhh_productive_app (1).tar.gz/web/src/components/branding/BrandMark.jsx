import React from 'react';

export default function BrandMark({ className = '', size = 'md' }) {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  };

  return (
    <img 
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/696b80034c7e55964cb716d5/ce26c3cbe_2f5a10156_6fbeeaeee_file_00000000936071f5b7d2ecf4d22a9f66.png"
      alt="Blessed Hope Healthcare"
      className={`${sizeClasses[size]} rounded-lg object-cover ${className}`}
    />
  );
}

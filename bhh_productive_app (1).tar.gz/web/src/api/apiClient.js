import { appParams } from '@/lib/app-params';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://api-bhh.icholding.cloud';

class ApiClient {
  constructor() {
    this.baseUrl = API_BASE_URL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const token = localStorage.getItem('base44_access_token') || localStorage.getItem('token');
    
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Network response was not ok' }));
      throw new Error(error.message || `Error ${response.status}: ${response.statusText}`);
    }

    return response.json();
  }

  get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  }

  post(endpoint, data) {
    return this.request(endpoint, { method: 'POST', body: JSON.stringify(data) });
  }

  put(endpoint, data) {
    return this.request(endpoint, { method: 'PUT', body: JSON.stringify(data) });
  }

  patch(endpoint, data) {
    return this.request(endpoint, { method: 'PATCH', body: JSON.stringify(data) });
  }

  delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }

  // Helper to simulate the base44 entity interface
  get entities() {
    const self = this;
    return new Proxy({}, {
      get(target, entityName) {
        return {
          list: (sort) => self.get(`/v1/entities/${entityName}${sort ? `?sort=${sort}` : ''}`),
          filter: (filter, sort) => self.post(`/v1/entities/${entityName}/filter${sort ? `?sort=${sort}` : ''}`, filter),
          get: (id) => self.get(`/v1/entities/${entityName}/${id}`),
          create: (data) => self.post(`/v1/entities/${entityName}`, data),
          update: (id, data) => self.patch(`/v1/entities/${entityName}/${id}`, data),
          delete: (id) => self.delete(`/v1/entities/${entityName}/${id}`),
          subscribe: (callback) => {
             console.warn('Real-time subscriptions not yet implemented in custom backend');
             return () => {}; // No-op unsubscribe
          }
        };
      }
    });
  }

  get auth() {
    return {
      me: () => this.get('/auth/me'),
      logout: () => {
        localStorage.removeItem('token');
        localStorage.removeItem('base44_access_token');
        window.location.href = '/';
      },
      redirectToLogin: () => {
        window.location.href = '/auth';
      }
    };
  }

  get integrations() {
    return {
      Core: {
        InvokeLLM: (data) => this.post('/v1/ai/invoke', data),
        UploadFile: (data) => {
           const formData = new FormData();
           formData.append('file', data.file);
           return fetch(`${this.baseUrl}/v1/files/upload`, {
             method: 'POST',
             body: formData,
             headers: {
               'Authorization': `Bearer ${localStorage.getItem('token')}`
             }
           }).then(r => r.json());
        }
      }
    };
  }
}

export const apiClient = new ApiClient();

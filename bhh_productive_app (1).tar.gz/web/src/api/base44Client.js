import { apiClient } from './apiClient';

// This is a bridge to allow the transition from @base44/sdk to our custom backend
// The app uses import { base44 } from '@/api/base44Client' in many places.
export const base44 = apiClient;

// Use this for direct API calls
export const API = import.meta.env.VITE_API_BASE_URL;

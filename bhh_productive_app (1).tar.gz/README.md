# Blessed Hope Healthcare (BHH)

Sovereign healthcare platform built with Vite, Node.js, and Supabase.

## Project Structure

- `/web`: Vite-based frontend
- `/api`: Node/Express backend
- `/supabase`: Database migrations and configuration

## Deployment (Render)

### Frontend (Static Site)
- **Root Directory**: `web`
- **Build Command**: `npm ci && npm run build`
- **Publish Directory**: `dist`
- **Domain**: `https://bhh.icholding.cloud`

### Backend (Web Service)
- **Root Directory**: `api`
- **Build Command**: `npm install`
- **Start Command**: `node src/server.js`
- **Domain**: `https://api-bhh.icholding.cloud`

## Tech Stack
- **Frontend**: React (Vite), Tailwind CSS, Framer Motion
- **Backend**: Node.js, Express, Resend (Email), Backblaze B2 (Files)
- **Database**: Supabase (PostgreSQL)
- **AI**: OpenAI / Claude via HackerAI6

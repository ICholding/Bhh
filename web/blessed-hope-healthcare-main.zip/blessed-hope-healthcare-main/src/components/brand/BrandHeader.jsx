import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function BrandHeader({ 
  showBack = false, 
  onBack,
  title,
  subtitle,
  rightAction
}) {
  return (
    <header className="sticky top-0 z-40 px-4 py-3 bg-white/90 backdrop-blur-md shadow-sm flex items-center justify-between">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {showBack && (
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onBack}
            className="rounded-full text-gray-700 flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
        )}
        {title && (
          <div className="flex flex-col min-w-0">
            <span className="font-bold text-gray-900 truncate">{title}</span>
            {subtitle && (
              <span className="text-xs text-gray-500 truncate">{subtitle}</span>
            )}
          </div>
        )}
      </div>
      
      {rightAction}
    </header>
  );
}
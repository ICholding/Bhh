import React, { useState } from 'react';
import BrandMark from './BrandMark';

export default function BrandLogo({ 
  size = 40, 
  alt = 'Support Assistant',
  variant = 'inline',
  className = '' 
}) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return <BrandMark size={size} className={className} />;
  }

  return (
    <img
      src="/logo.png"
      alt={alt}
      className={`rounded-full flex-shrink-0 object-cover ${className}`}
      style={{ width: size, height: size }}
      onError={() => setHasError(true)}
    />
  );
}

// Brand Mode Configuration
export const BRAND_MODE = "lite"; // "full" | "lite"

// Lite Mode Titles (no logo, no "BHH" text)
export const LITE_TITLES = {
  supportChat: "Support Assistant",
  adminChat: "Admin Assistant",
  workerChat: "Assistant",
  genericChat: "Assistant",
};

// Only used in Splash and Landing Footer
export const SPLASH_LOGO = "/assets/bhh-logo.png";
export const APP_NAME = "Blessed Hope Healthcare";
export const COMPANY_NAME = "Blessed Hope Healthcare";
export const SUPPORT_PHONE_DISPLAY = "(555) 123-4567";
export const SUPPORT_PHONE_TEL = "5551234567";
export const SUPPORT_EMAIL = "support@blessedhopehc.com";

export const getAgentConfig = (agentType) => {
  const configs = {
    admin: {
      agentType: 'admin',
      title: 'Admin Assistant',
      subtitle: 'Operations Support',
      portal: 'admin',
      starterMessage: 'Hello! I\'m your admin assistant. How can I help you today?',
      quickActions: ['View jobs', 'Manage staff', 'Check payouts']
    },
    worker: {
      agentType: 'worker',
      title: 'Worker Support',
      subtitle: 'Job Assistance',
      portal: 'worker',
      starterMessage: 'Hi! I\'m here to help with your assignments and schedule.',
      quickActions: ['My jobs', 'Schedule', 'Payment info']
    },
    customer: {
      agentType: 'customer',
      title: 'Support Assistant',
      subtitle: 'How can we help?',
      portal: 'customer',
      starterMessage: 'Hi! What can I help you with today?',
      quickActions: ['Book service', 'Track appointment', 'Billing help']
    }
  };
  
  return configs[agentType] || configs.customer;
};
import React from 'react';
import { User } from 'lucide-react';
import { motion } from 'framer-motion';
import AgentAvatar from '../brand/AgentAvatar';

export default function MessageBubble({ message }) {
  const isBot = message.role === 'bot';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex items-end gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
    >
      <div className={`${isBot ? 'max-w-[85%]' : 'max-w-[80%]'} rounded-2xl px-5 py-3.5 ${
        isBot 
          ? 'bg-white shadow-sm border border-gray-100 rounded-bl-md' 
          : 'bg-gradient-to-r from-blue-500 to-teal-500 text-white rounded-br-md shadow-md'
      }`}>
        <p className={`text-sm leading-relaxed ${isBot ? 'text-gray-800' : 'text-white'}`}>
          {message.content}
        </p>
      </div>
      
      {!isBot && (
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-400 to-gray-500 flex items-center justify-center flex-shrink-0 shadow-sm">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </motion.div>
  );
}
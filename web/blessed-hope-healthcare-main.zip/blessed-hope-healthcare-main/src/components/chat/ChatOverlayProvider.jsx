import React, { createContext, useContext, useState } from 'react';
import ChatOverlay from './ChatOverlay';

const ChatOverlayContext = createContext();

export function ChatOverlayProvider({ children }) {
  const [isOpen, setIsOpen] = useState(false);
  const [config, setConfig] = useState({});

  const openChat = (chatConfig) => {
    setConfig(chatConfig);
    setIsOpen(true);
  };

  const closeChat = () => {
    setIsOpen(false);
  };

  return (
    <ChatOverlayContext.Provider value={{ openChat, closeChat, isOpen, config }}>
      {children}
      <ChatOverlay isOpen={isOpen} onClose={closeChat} config={config} />
    </ChatOverlayContext.Provider>
  );
}

export function useChatOverlay() {
  const context = useContext(ChatOverlayContext);
  if (!context) {
    throw new Error('useChatOverlay must be used within ChatOverlayProvider');
  }
  return context;
}
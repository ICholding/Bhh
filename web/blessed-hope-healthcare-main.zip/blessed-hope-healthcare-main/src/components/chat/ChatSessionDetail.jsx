import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, CheckCircle, AlertTriangle, Star, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

export default function ChatSessionDetail({ session, onClose, onResolve, onEscalate }) {
  const queryClient = useQueryClient();
  const [agentName, setAgentName] = useState('');
  const [notes, setNotes] = useState('');
  const [rating, setRating] = useState(session.satisfaction_rating || 0);

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.ChatSession.update(session.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatSessions'] });
    },
  });

  const handleAssignAgent = () => {
    if (agentName.trim()) {
      updateMutation.mutate({ assigned_agent: agentName });
      setAgentName('');
    }
  };

  const handleSaveNotes = () => {
    if (notes.trim()) {
      updateMutation.mutate({ admin_notes: notes });
    }
  };

  const handleRating = (newRating) => {
    setRating(newRating);
    updateMutation.mutate({ satisfaction_rating: newRating });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-blue-100 text-blue-700';
      case 'resolved': return 'bg-green-100 text-green-700';
      case 'escalated': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <Button variant="ghost" size="icon" onClick={onClose}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold text-gray-900">Session Details</h1>
          <p className="text-xs text-gray-500">{session.user_name || 'Anonymous'}</p>
        </div>
        <Badge className={getStatusColor(session.status)}>
          {session.status}
        </Badge>
      </header>

      <div className="p-4 space-y-4 max-w-2xl mx-auto">
        {/* Quick Actions */}
        {session.status === 'active' && (
          <Card>
            <CardContent className="pt-4">
              <div className="flex gap-2">
                <Button 
                  onClick={() => onResolve(session.id)}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark Resolved
                </Button>
                <Button 
                  onClick={() => onEscalate(session.id)}
                  variant="destructive"
                  className="flex-1"
                >
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Escalate
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Session Info */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Session Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-gray-500">Portal</p>
                <p className="font-medium capitalize">{session.portal}</p>
              </div>
              <div>
                <p className="text-gray-500">Messages</p>
                <p className="font-medium">{session.message_count || 0}</p>
              </div>
              <div>
                <p className="text-gray-500">Duration</p>
                <p className="font-medium">{session.duration_minutes || 0} minutes</p>
              </div>
              <div>
                <p className="text-gray-500">Resolution Time</p>
                <p className="font-medium">{session.resolution_time_minutes || 'N/A'} min</p>
              </div>
            </div>

            {session.topics && session.topics.length > 0 && (
              <div>
                <p className="text-gray-500 text-sm mb-2">Topics</p>
                <div className="flex flex-wrap gap-2">
                  {session.topics.map((topic, idx) => (
                    <Badge key={idx} variant="outline">{topic}</Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Queries */}
        {session.queries && session.queries.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">User Queries</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {session.queries.map((query, idx) => (
                <div key={idx} className="p-3 bg-gray-50 rounded-lg text-sm">
                  {query}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Assign Agent */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Agent Assignment</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {session.assigned_agent && (
              <div className="p-3 bg-blue-50 rounded-lg text-sm">
                <p className="text-gray-600">Assigned to:</p>
                <p className="font-medium text-blue-900">{session.assigned_agent}</p>
              </div>
            )}
            <div className="flex gap-2">
              <Input
                value={agentName}
                onChange={(e) => setAgentName(e.target.value)}
                placeholder="Enter agent name"
              />
              <Button onClick={handleAssignAgent}>
                <UserPlus className="w-4 h-4 mr-2" />
                Assign
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Satisfaction Rating */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Satisfaction Rating</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => handleRating(star)}
                  className="transition-all"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= rating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            <p className="text-sm text-gray-500 mt-2">
              {rating > 0 ? `${rating} out of 5 stars` : 'No rating yet'}
            </p>
          </CardContent>
        </Card>

        {/* Admin Notes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Admin Notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add internal notes about this session..."
              rows={4}
            />
            <Button onClick={handleSaveNotes} className="w-full">
              Save Notes
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
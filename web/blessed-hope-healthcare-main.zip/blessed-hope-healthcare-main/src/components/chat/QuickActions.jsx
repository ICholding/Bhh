import React from 'react';
import { motion } from 'framer-motion';

export default function QuickActions({ actions, onSelect }) {
  return (
    <div className="px-4 pb-4 max-w-3xl mx-auto w-full">
      <p className="text-xs font-medium text-gray-500 mb-3">Quick actions:</p>
      <div className="flex flex-wrap gap-2.5">
        {actions.map((action, index) => (
          <motion.button
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => onSelect(action)}
            className="min-h-[44px] px-5 py-2.5 bg-white border border-blue-200 rounded-full text-sm font-medium text-blue-600 hover:bg-blue-50 hover:border-blue-300 transition-all active:scale-95 shadow-sm"
          >
            {action}
          </motion.button>
        ))}
      </div>
    </div>
  );
}
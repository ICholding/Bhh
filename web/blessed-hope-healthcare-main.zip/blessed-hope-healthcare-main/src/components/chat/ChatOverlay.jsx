import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import MessageBubble from './MessageBubble';
import { getAgentConfig } from './agents.config';

export default function ChatOverlay({ 
  isOpen,
  onClose,
  config = {}
}) {
  const agentConfig = getAgentConfig(config.agentType || 'customer');
  const {
    title = agentConfig.title,
    subtitle = agentConfig.subtitle,
    starterMessage = agentConfig.starterMessage,
    quickActions = agentConfig.quickActions,
    portal = agentConfig.portal
  } = { ...agentConfig, ...config };

  const [messages, setMessages] = useState([
    { id: 1, role: 'bot', content: starterMessage }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  // Load knowledge base
  const { data: knowledgeBase = [] } = useQuery({
    queryKey: ['knowledgeBase'],
    queryFn: () => base44.entities.KnowledgeBase.list('-updated_date', 500),
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Reset messages when config changes
  useEffect(() => {
    if (isOpen) {
      setMessages([{ id: 1, role: 'bot', content: starterMessage }]);
      setInput('');
    }
  }, [isOpen, starterMessage]);

  const handleSend = (text = input) => {
    if (!text.trim()) return;
    
    const userMessage = { id: Date.now(), role: 'user', content: text };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // AI responses based on portal type and query
    setTimeout(() => {
      let botResponse = "I understand. Let me help you with that.";
      const query = text.toLowerCase();
      
      // Search knowledge base first
      const relevantArticles = knowledgeBase.filter(article => {
        if (!article.is_published) return false;
        if (article.portal !== 'all' && article.portal !== portal) return false;
        
        const titleMatch = article.title.toLowerCase().includes(query);
        const contentMatch = article.content.toLowerCase().includes(query);
        const keywordMatch = article.keywords?.some(k => query.includes(k.toLowerCase()) || k.toLowerCase().includes(query));
        
        return titleMatch || contentMatch || keywordMatch;
      }).slice(0, 2);
      
      // If we found relevant KB articles, use them
      if (relevantArticles.length > 0) {
        const mainArticle = relevantArticles[0];
        botResponse = mainArticle.content;
        
        // Track view
        base44.entities.KnowledgeBase.update(mainArticle.id, {
          view_count: (mainArticle.view_count || 0) + 1
        }).catch(() => {});
        
        if (relevantArticles.length > 1) {
          botResponse += `\n\n**Related**: ${relevantArticles[1].title}`;
        }
      } else {
        // Fallback to hardcoded responses
        if (portal === 'worker') {
          if (query.includes('job') || query.includes('assignment')) {
            botResponse = "To view your current assignments, navigate to the Jobs tab. There you'll find complete job details including client information, service location, and time slots.";
          } else if (query.includes('shift') || query.includes('availability')) {
            botResponse = "Manage your availability status by going to your Profile page. Toggle your availability switch to indicate when you're accepting new assignments.";
          }
        } else if (portal === 'admin') {
          if (query.includes('request') || query.includes('service')) {
            botResponse = "Access the Operations Overview to see all service requests. Filter by status or priority level. You can quickly assign available workers and track completion metrics.";
          } else if (query.includes('staff') || query.includes('employee')) {
            botResponse = "Navigate to the Users section to manage your workforce. View real-time worker availability, review performance ratings, and assign new jobs.";
          }
        } else {
          if (query.includes('service') || query.includes('book')) {
            botResponse = "To request a service, return to your home screen and tap the service type you need. Select your preferred date and time, and we'll match you with an available qualified provider.";
          } else if (query.includes('schedule') || query.includes('appointment')) {
            botResponse = "View all your upcoming appointments on the home screen. To reschedule or cancel, you must do so at least 24 hours in advance.";
          } else if (query.includes('payment') || query.includes('billing')) {
            botResponse = "Your billing information and membership plan details are available in your Profile. To update payment methods or change your subscription tier, navigate to Profile > Billing Settings.";
          }
        }
      }
      
      const botMessage = {
        id: Date.now() + 1,
        role: 'bot',
        content: botResponse
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1200);
  };

  const handleQuickAction = (action) => {
    handleSend(action);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/25 z-40"
          />

          {/* Bottom Sheet */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 flex justify-center"
          >
            <div 
              className="w-full max-w-2xl bg-white rounded-t-3xl shadow-2xl flex flex-col"
              style={{ height: '90vh', maxHeight: '90vh' }}
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-500 to-teal-500 rounded-t-3xl px-5 pt-4 pb-3">
                {/* Drag Handle */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2">
                  <div className="w-10 h-1 rounded-full bg-white/40" />
                </div>

                <div className="flex items-center justify-between mt-2">
                  <div className="flex-1 min-w-0">
                    <h2 className="text-lg font-bold text-white truncate">{title}</h2>
                    {subtitle && <p className="text-xs text-white/90 truncate">{subtitle}</p>}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 rounded-full text-white hover:bg-white/20"
                    >
                      <Clock className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={onClose}
                      className="h-8 w-8 rounded-full text-white hover:bg-white/20"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-gray-50">
                {messages.map(message => (
                  <MessageBubble key={message.id} message={message} />
                ))}
                
                {isTyping && (
                  <div className="flex items-start gap-2">
                    <div className="bg-white rounded-2xl px-5 py-3 shadow-sm">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Actions */}
              {quickActions.length > 0 && messages.length < 3 && (
                <div className="px-4 pb-2 bg-white border-t border-gray-100">
                  <div className="flex gap-2 overflow-x-auto pb-2 pt-3 scrollbar-hide">
                    {quickActions.map((action, index) => (
                      <button
                        key={index}
                        onClick={() => handleQuickAction(action)}
                        className="flex-shrink-0 px-4 py-2 bg-blue-50 text-blue-600 rounded-full text-sm font-medium hover:bg-blue-100 active:scale-95 transition-all"
                      >
                        {action}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Area */}
              <div className="border-t border-gray-100 p-4 bg-white rounded-b-3xl">
                <form 
                  onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                  className="flex items-center gap-3"
                >
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="What would you like to know?"
                    className="flex-1 h-11 rounded-full border-gray-200 focus:border-blue-400 px-4"
                  />
                  <Button 
                    type="submit" 
                    size="icon"
                    disabled={!input.trim()}
                    className="h-11 w-11 rounded-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 disabled:opacity-40 shadow-md flex-shrink-0"
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </form>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
// Brand configuration for the application
export const BRAND_MODE = "lite"; // "full" or "lite"

// Titles for different contexts in lite mode
export const LITE_TITLES = {
  supportChat: "Support Assistant",
  workerChat: "Worker Assistant", 
  adminChat: "Admin Assistant"
};

// App name for general use
export const APP_NAME = "Support Assistant";
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useChatOverlay } from '@/components/chat/ChatOverlayProvider';
import { getAgentConfig } from '@/components/chat/agents.config.js';

export default function AdminChat() {
  const navigate = useNavigate();
  const { openChat } = useChatOverlay();

  React.useEffect(() => {
    // Route trap: open overlay immediately and redirect back
    openChat(getAgentConfig('admin'));
    navigate(createPageUrl('AdminDashboard'), { replace: true });
  }, [navigate, openChat]);

  return null; // Route trap - overlay handles everything
}
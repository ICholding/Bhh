import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useChatOverlay } from '@/components/chat/ChatOverlayProvider';
import { getAgentConfig } from '@/components/chat/agents.config';

export default function EmployeeChat() {
  const navigate = useNavigate();
  const { openChat } = useChatOverlay();

  React.useEffect(() => {
    // Route trap: open overlay immediately and redirect back
    openChat(getAgentConfig('worker'));
    navigate(createPageUrl('EmployeeDashboard'), { replace: true });
  }, [navigate, openChat]);

  return null; // Route trap - overlay handles everything
}
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useChatOverlay } from '@/components/chat/ChatOverlayProvider';
import { getAgentConfig } from '@/components/chat/agents.config';

export default function CustomerChat() {
  const navigate = useNavigate();
  const { openChat } = useChatOverlay();

  React.useEffect(() => {
    // Route trap: open overlay immediately and redirect back
    openChat(getAgentConfig('customer'));
    navigate(createPageUrl('ServicePortal'), { replace: true });
  }, [navigate, openChat]);

  return null; // Route trap - overlay handles everything
}
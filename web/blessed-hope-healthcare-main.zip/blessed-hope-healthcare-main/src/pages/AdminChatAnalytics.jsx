import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, MessageSquare, TrendingUp, Clock, ThumbsUp, Users, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function AdminChatAnalytics() {
  const navigate = useNavigate();
  const [timeframe, setTimeframe] = useState('week');

  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ['chatSessions'],
    queryFn: () => base44.entities.ChatSession.list('-created_date', 500),
  });

  // Calculate metrics
  const activeSessions = sessions.filter(s => s.status === 'active').length;
  const totalSessions = sessions.length;
  const avgResolutionTime = sessions.filter(s => s.resolution_time_minutes)
    .reduce((acc, s) => acc + s.resolution_time_minutes, 0) / 
    (sessions.filter(s => s.resolution_time_minutes).length || 1);
  const avgSatisfaction = sessions.filter(s => s.satisfaction_rating)
    .reduce((acc, s) => acc + s.satisfaction_rating, 0) / 
    (sessions.filter(s => s.satisfaction_rating).length || 1);
  const resolutionRate = (sessions.filter(s => s.resolved).length / (totalSessions || 1)) * 100;

  // Common queries analysis
  const allQueries = sessions.flatMap(s => s.queries || []);
  const queryFrequency = allQueries.reduce((acc, query) => {
    const key = query.toLowerCase().slice(0, 50);
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  const topQueries = Object.entries(queryFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  // Portal distribution
  const portalStats = sessions.reduce((acc, s) => {
    acc[s.portal] = (acc[s.portal] || 0) + 1;
    return acc;
  }, {});

  // Topics analysis
  const allTopics = sessions.flatMap(s => s.topics || []);
  const topicFrequency = allTopics.reduce((acc, topic) => {
    acc[topic] = (acc[topic] || 0) + 1;
    return acc;
  }, {});
  const topTopics = Object.entries(topicFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate(createPageUrl('AdminDashboard'))}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-lg font-semibold text-gray-900">Chat Analytics</h1>
          <p className="text-xs text-gray-500">Performance & insights</p>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="pt-5">
              <div className="flex items-center justify-between mb-2">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                <span className="text-xs font-medium text-blue-600">Live</span>
              </div>
              <p className="text-2xl font-bold text-blue-900">{activeSessions}</p>
              <p className="text-xs text-blue-700">Active Conversations</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="pt-5">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <span className="text-xs font-medium text-green-600">{resolutionRate.toFixed(0)}%</span>
              </div>
              <p className="text-2xl font-bold text-green-900">{totalSessions}</p>
              <p className="text-xs text-green-700">Total Sessions</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
            <CardContent className="pt-5">
              <div className="flex items-center justify-between mb-2">
                <Clock className="w-5 h-5 text-amber-600" />
                <span className="text-xs font-medium text-amber-600">Avg</span>
              </div>
              <p className="text-2xl font-bold text-amber-900">{avgResolutionTime.toFixed(1)}m</p>
              <p className="text-xs text-amber-700">Resolution Time</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="pt-5">
              <div className="flex items-center justify-between mb-2">
                <ThumbsUp className="w-5 h-5 text-purple-600" />
                <span className="text-xs font-medium text-purple-600">★ {avgSatisfaction.toFixed(1)}</span>
              </div>
              <p className="text-2xl font-bold text-purple-900">{sessions.filter(s => s.satisfaction_rating).length}</p>
              <p className="text-xs text-purple-700">Rated Sessions</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs for detailed analytics */}
        <Tabs defaultValue="queries" className="w-full">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="queries">Queries</TabsTrigger>
            <TabsTrigger value="topics">Topics</TabsTrigger>
            <TabsTrigger value="portals">Portals</TabsTrigger>
          </TabsList>

          <TabsContent value="queries" className="space-y-3 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Common User Queries
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {topQueries.length === 0 ? (
                  <p className="text-sm text-gray-500 py-4 text-center">No query data yet</p>
                ) : (
                  topQueries.map(([query, count], idx) => (
                    <div key={idx} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                      <p className="text-sm text-gray-700 flex-1 truncate">{query}</p>
                      <span className="text-xs font-semibold text-blue-600 ml-2">×{count}</span>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="topics" className="space-y-3 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Discussion Topics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {topTopics.length === 0 ? (
                    <p className="text-sm text-gray-500 py-4 w-full text-center">No topic data yet</p>
                  ) : (
                    topTopics.map(([topic, count], idx) => (
                      <div key={idx} className="px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-full text-sm">
                        <span className="text-blue-700 font-medium">{topic}</span>
                        <span className="text-blue-500 ml-1.5">({count})</span>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="portals" className="space-y-3 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Portal Distribution
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(portalStats).map(([portal, count]) => (
                  <div key={portal}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700 capitalize">{portal}</span>
                      <span className="text-sm font-semibold text-gray-900">{count}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-teal-500 h-2 rounded-full transition-all"
                        style={{ width: `${(count / totalSessions) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
                {Object.keys(portalStats).length === 0 && (
                  <p className="text-sm text-gray-500 py-4 text-center">No portal data yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Recent Sessions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Recent Sessions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {sessions.slice(0, 5).map((session) => (
              <div key={session.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{session.user_name || 'Anonymous'}</p>
                  <p className="text-xs text-gray-500 capitalize">{session.portal} • {session.message_count || 0} messages</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    session.status === 'resolved' ? 'bg-green-100 text-green-700' :
                    session.status === 'active' ? 'bg-blue-100 text-blue-700' :
                    'bg-amber-100 text-amber-700'
                  }`}>
                    {session.status}
                  </span>
                  {session.satisfaction_rating && (
                    <p className="text-xs text-amber-600 mt-1">★ {session.satisfaction_rating}</p>
                  )}
                </div>
              </div>
            ))}
            {sessions.length === 0 && (
              <p className="text-sm text-gray-500 py-4 text-center">No sessions yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
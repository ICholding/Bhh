import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, MessageSquare, CheckCircle, AlertTriangle, Clock, UserPlus, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ChatSessionDetail from '@/components/chat/ChatSessionDetail';

export default function AdminChatManagement() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [selectedSession, setSelectedSession] = useState(null);
  const [statusFilter, setStatusFilter] = useState('all');

  const { data: sessions = [] } = useQuery({
    queryKey: ['chatSessions', statusFilter],
    queryFn: () => base44.entities.ChatSession.list('-updated_date', 500),
    refetchInterval: 5000, // Real-time updates every 5 seconds
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.ChatSession.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatSessions'] });
    },
  });

  const assignAgentMutation = useMutation({
    mutationFn: ({ id, agentName }) => 
      base44.entities.ChatSession.update(id, { assigned_agent: agentName }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatSessions'] });
    },
  });

  const filteredSessions = sessions.filter(session => {
    if (statusFilter === 'all') return true;
    return session.status === statusFilter;
  });

  const activeSessions = sessions.filter(s => s.status === 'active').length;
  const resolvedSessions = sessions.filter(s => s.status === 'resolved').length;
  const escalatedSessions = sessions.filter(s => s.status === 'escalated').length;

  const handleResolve = (sessionId) => {
    updateStatusMutation.mutate({ id: sessionId, status: 'resolved' });
  };

  const handleEscalate = (sessionId) => {
    updateStatusMutation.mutate({ id: sessionId, status: 'escalated' });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-blue-100 text-blue-700';
      case 'resolved': return 'bg-green-100 text-green-700';
      case 'escalated': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (selectedSession) {
    return (
      <ChatSessionDetail
        session={selectedSession}
        onClose={() => setSelectedSession(null)}
        onResolve={handleResolve}
        onEscalate={handleEscalate}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate(createPageUrl('AdminDashboard'))}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold text-gray-900">Chat Sessions</h1>
          <p className="text-xs text-gray-500">Real-time monitoring & management</p>
        </div>
        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
      </header>

      <div className="p-4 space-y-4">
        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="cursor-pointer" onClick={() => setStatusFilter('active')}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between mb-1">
                <MessageSquare className="w-4 h-4 text-blue-600" />
                <Badge className="bg-blue-100 text-blue-700 text-xs">Live</Badge>
              </div>
              <p className="text-2xl font-bold text-gray-900">{activeSessions}</p>
              <p className="text-xs text-gray-500">Active</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer" onClick={() => setStatusFilter('resolved')}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between mb-1">
                <CheckCircle className="w-4 h-4 text-green-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{resolvedSessions}</p>
              <p className="text-xs text-gray-500">Resolved</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer" onClick={() => setStatusFilter('escalated')}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between mb-1">
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{escalatedSessions}</p>
              <p className="text-xs text-gray-500">Escalated</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-full">
          <TabsList className="w-full grid grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="escalated">Escalated</TabsTrigger>
            <TabsTrigger value="resolved">Resolved</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Sessions List */}
        <div className="space-y-3">
          {filteredSessions.map((session) => (
            <Card key={session.id} className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setSelectedSession(session)}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900">
                        {session.user_name || 'Anonymous User'}
                      </h3>
                      <Badge className={getStatusColor(session.status)} variant="secondary">
                        {session.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 capitalize">
                      {session.portal} Portal • {session.message_count || 0} messages
                    </p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedSession(session);
                    }}
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>

                {/* Session Info */}
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  {session.duration_minutes && (
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {session.duration_minutes}m
                    </span>
                  )}
                  {session.topics && session.topics.length > 0 && (
                    <div className="flex gap-1 flex-wrap">
                      {session.topics.slice(0, 2).map((topic, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Quick Actions */}
                {session.status === 'active' && (
                  <div className="flex gap-2 mt-3">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleResolve(session.id);
                      }}
                      className="text-green-600"
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Resolve
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEscalate(session.id);
                      }}
                      className="text-red-600"
                    >
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Escalate
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}

          {filteredSessions.length === 0 && (
            <div className="text-center py-12">
              <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No {statusFilter !== 'all' ? statusFilter : ''} sessions</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
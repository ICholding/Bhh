import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from '@/utils';

export default function Splash() {
  const nav = useNavigate();
  const [p, setP] = useState(1);
  const raf = useRef(null);
  const start = useRef(null);

  useEffect(() => {
    // If already shown once this session, skip
    if (sessionStorage.getItem("bhh_splash_done") === "1") {
      nav(createPageUrl('Landing'), { replace: true });
      return;
    }

    const DURATION_MS = 2600; // 2.6s total

    const tick = (t) => {
      if (!start.current) start.current = t;
      const elapsed = t - start.current;
      const progress = Math.min(1, elapsed / DURATION_MS);
      const value = Math.max(1, Math.floor(progress * 100));

      setP(value);

      if (progress < 1) {
        raf.current = requestAnimationFrame(tick);
      } else {
        sessionStorage.setItem("bhh_splash_done", "1");
        nav(createPageUrl('Landing'), { replace: true });
      }
    };

    raf.current = requestAnimationFrame(tick);

    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [nav]);

  return (
    <div style={styles.wrap}>
      <style>{keyframes}</style>
      <div style={styles.logoContainer}>
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/696b80034c7e55964cb716d5/1b3117711_file_0000000052c871fda8042e2b6e67a298.png"
          alt="BHH Logo"
          style={styles.logo}
        />
        
        <div style={styles.loaderContainer}>
          <div style={styles.percent}>{p}%</div>
          <div style={styles.barTrack}>
            <div style={{ ...styles.barFill, width: `${p}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
}

const keyframes = `
  @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-15px); }
  }
  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.9); }
    to { opacity: 1; transform: scale(1); }
  }
`;

const styles = {
  wrap: {
    height: "100vh",
    width: "100vw",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(135deg, #e8f0f7 0%, #d4e4f1 100%)",
    overflow: "hidden",
  },
  logoContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 40,
  },
  logo: {
    width: 280,
    height: 280,
    objectFit: "contain",
    animation: "fadeIn 0.6s ease-in, float 3s ease-in-out infinite",
    filter: "drop-shadow(0 10px 20px rgba(30, 90, 158, 0.15))",
  },
  loaderContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 12,
    width: 280,
  },
  percent: {
    fontSize: 18,
    fontWeight: 600,
    color: "#1e5a9e",
    letterSpacing: "0.5px",
  },
  barTrack: {
    width: "100%",
    height: 6,
    borderRadius: 999,
    background: "rgba(30, 90, 158, 0.15)",
    overflow: "hidden",
  },
  barFill: {
    height: "100%",
    borderRadius: 999,
    background: "linear-gradient(90deg, #1e5a9e, #3b9fd4)",
    transition: "width 60ms linear",
  },
};
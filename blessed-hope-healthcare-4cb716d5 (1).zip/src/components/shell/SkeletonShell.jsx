import React from 'react';
import BrandHeader from '../brand/BrandHeader';
import BrandLogo from '../brand/BrandLogo';

export default function SkeletonShell({ 
  children, 
  loading = false,
  title,
  subtitle,
  onBack,
  showHeader = true,
  rightAction
}) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {showHeader && (
        <BrandHeader 
          title={title}
          subtitle={subtitle}
          showBack={!!onBack}
          onBack={onBack}
          rightAction={rightAction}
        />
      )}
      
      <main className="flex-1">
        {loading ? <LoadingSkeleton /> : children}
      </main>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="animate-pulse p-4 space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <BrandLogo size={48} />
        <div className="flex-1">
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2" />
          <div className="h-3 bg-gray-200 rounded w-1/3" />
        </div>
      </div>
      <div className="h-24 bg-gray-200 rounded-xl" />
      <div className="h-16 bg-gray-200 rounded-xl" />
      <div className="h-16 bg-gray-200 rounded-xl" />
      <div className="h-32 bg-gray-200 rounded-xl" />
    </div>
  );
}
import React from 'react';
import { Phone } from 'lucide-react';
import { SUPPORT_PHONE_DISPLAY, SUPPORT_PHONE_TEL } from '../brand/brand.config';

export default function CompanyFooter() {
  return (
    <div className="bg-white border-t border-gray-200 px-6 py-4">
      <div className="max-w-md mx-auto text-center">
        <p className="text-xs text-gray-500 mb-2">Company Contact</p>
        <a 
          href={`tel:${SUPPORT_PHONE_TEL}`}
          className="inline-flex items-center gap-2 text-blue-600 font-medium hover:text-blue-700 transition-colors"
        >
          <Phone className="w-4 h-4" />
          {SUPPORT_PHONE_DISPLAY}
        </a>
      </div>
    </div>
  );
}
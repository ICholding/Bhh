import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Briefcase, CheckCircle, UserPlus, DollarSign, 
  MessageCircle, Bell, AlertCircle, TrendingUp 
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const activityIcons = {
  job_created: Briefcase,
  job_completed: CheckCircle,
  worker_assigned: UserPlus,
  client_registered: UserPlus,
  payment_processed: DollarSign,
  message_sent: MessageCircle,
  system_update: Bell
};

const activityColors = {
  job_created: 'bg-blue-100 text-blue-600',
  job_completed: 'bg-green-100 text-green-600',
  worker_assigned: 'bg-purple-100 text-purple-600',
  client_registered: 'bg-teal-100 text-teal-600',
  payment_processed: 'bg-yellow-100 text-yellow-600',
  message_sent: 'bg-cyan-100 text-cyan-600',
  system_update: 'bg-orange-100 text-orange-600'
};

const priorityBorders = {
  urgent: 'border-l-4 border-red-500',
  high: 'border-l-4 border-orange-500',
  normal: '',
  low: ''
};

export default function ActivityFeed({ portal, limit = 10, showTitle = true }) {
  const [activities, setActivities] = useState([]);

  const { data: initialActivities = [] } = useQuery({
    queryKey: ['activities', portal],
    queryFn: () => base44.entities.Activity.list('-created_date', limit * 2)
  });

  useEffect(() => {
    const filtered = initialActivities.filter(a => 
      a.target_portals?.includes(portal)
    ).slice(0, limit);
    setActivities(filtered);
  }, [initialActivities, portal, limit]);

  // Real-time subscription
  useEffect(() => {
    const unsubscribe = base44.entities.Activity.subscribe((event) => {
      if (event.type === 'create' && event.data.target_portals?.includes(portal)) {
        setActivities(prev => [event.data, ...prev].slice(0, limit));
      } else if (event.type === 'update') {
        setActivities(prev => 
          prev.map(a => a.id === event.id ? event.data : a)
        );
      } else if (event.type === 'delete') {
        setActivities(prev => prev.filter(a => a.id !== event.id));
      }
    });

    return unsubscribe;
  }, [portal, limit]);

  if (activities.length === 0) {
    return (
      <div className="bg-white rounded-xl p-8 text-center border border-gray-100">
        <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-500">No recent activity</p>
      </div>
    );
  }

  return (
    <div>
      {showTitle && (
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-gray-900">Activity Feed</h2>
          <div className="flex items-center gap-1 text-xs text-teal-600">
            <div className="w-2 h-2 rounded-full bg-teal-600 animate-pulse" />
            Live
          </div>
        </div>
      )}

      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {activities.map((activity, index) => {
            const Icon = activityIcons[activity.type] || Bell;
            const colorClass = activityColors[activity.type] || 'bg-gray-100 text-gray-600';
            const borderClass = priorityBorders[activity.priority] || '';

            return (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
                className={`bg-white rounded-xl p-4 border border-gray-100 hover:shadow-sm transition-shadow ${borderClass}`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl ${colorClass} flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm">{activity.title}</p>
                    {activity.description && (
                      <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                      {activity.actor_name && (
                        <span>{activity.actor_name}</span>
                      )}
                      <span>
                        {formatDistanceToNow(new Date(activity.created_date), { addSuffix: true })}
                      </span>
                      {activity.priority === 'urgent' && (
                        <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-600 font-medium">
                          Urgent
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
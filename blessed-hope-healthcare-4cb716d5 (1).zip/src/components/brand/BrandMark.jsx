import React from 'react';
import { APP_NAME } from './brand.config';

export default function BrandMark({ size = 40, className = '' }) {
  return (
    <div 
      className={`rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center text-white font-bold flex-shrink-0 ${className}`}
      style={{ width: size, height: size, fontSize: size * 0.35 }}
    >
      {APP_NAME}
    </div>
  );
}
export const APP_NAME = "BHH";
export const APP_FULL_NAME = "Blessed Hope Healthcare";
export const TAGLINE = "Support Assistant";
export const SUPPORT_PHONE_DISPLAY = "(770) 891-3267";
export const SUPPORT_PHONE_TEL = "+17708913267";
export const LOGO_SRC = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/696b80034c7e55964cb716d5/2ee5543ea_file_00000000031471fd93f38651ab7c68e4.png";
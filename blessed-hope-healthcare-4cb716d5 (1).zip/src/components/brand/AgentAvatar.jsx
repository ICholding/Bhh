import React from 'react';
import BrandLogo from './BrandLogo';
import { APP_FULL_NAME } from './brand.config';

export default function AgentAvatar({ 
  size = 40, 
  showName = false, 
  showSubtext = false,
  className = '' 
}) {
  if (!showName) {
    return <BrandLogo size={size} variant="avatar" className={className} />;
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <BrandLogo size={size} variant="avatar" />
      <div className="flex flex-col min-w-0">
        <span className="text-sm font-semibold text-gray-900">{APP_FULL_NAME}</span>
        {showSubtext && (
          <span className="text-xs text-gray-500">Support Agent</span>
        )}
      </div>
    </div>
  );
}
import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import BrandLogo from './BrandLogo';
import { APP_FULL_NAME, TAGLINE } from './brand.config';

export default function BrandHeader({ 
  showBack = false, 
  onBack,
  title = APP_FULL_NAME,
  subtitle = TAGLINE,
  rightAction
}) {
  return (
    <header className="sticky top-0 z-40 px-4 py-3 bg-white/90 backdrop-blur-md shadow-sm flex items-center justify-between">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {showBack && (
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onBack}
            className="rounded-full text-gray-700 flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
        )}
        <div className="flex flex-col min-w-0">
          <span className="font-semibold text-gray-900 text-sm truncate">{title}</span>
          {subtitle && (
            <span className="text-xs text-gray-500 truncate">{subtitle}</span>
          )}
        </div>
      </div>
      
      {rightAction || <BrandLogo size={36} variant="header" />}
    </header>
  );
}
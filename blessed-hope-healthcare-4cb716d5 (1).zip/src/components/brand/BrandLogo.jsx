import React, { useState } from 'react';
import { LOGO_SRC, APP_NAME } from './brand.config';
import BrandMark from './BrandMark';

export default function BrandLogo({ 
  size = 40, 
  alt = APP_NAME,
  variant = 'inline',
  className = '' 
}) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return <BrandMark size={size} className={className} />;
  }

  return (
    <img
      src={LOGO_SRC}
      alt={alt}
      className={`rounded-full flex-shrink-0 object-cover ${className}`}
      style={{ width: size, height: size }}
      onError={() => setHasError(true)}
    />
  );
}
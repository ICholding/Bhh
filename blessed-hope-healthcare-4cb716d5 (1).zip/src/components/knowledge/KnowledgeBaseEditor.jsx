import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

export default function KnowledgeBaseEditor({ article, onClose }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    title: article?.title || '',
    category: article?.category || 'FAQ',
    content: article?.content || '',
    keywords: article?.keywords?.join(', ') || '',
    portal: article?.portal || 'all',
    is_published: article?.is_published ?? true,
  });

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const payload = {
        ...data,
        keywords: data.keywords.split(',').map(k => k.trim()).filter(Boolean),
      };
      
      if (article?.id) {
        return base44.entities.KnowledgeBase.update(article.id, payload);
      }
      return base44.entities.KnowledgeBase.create(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['knowledgeBase'] });
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <Button variant="ghost" size="icon" onClick={onClose}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-semibold text-gray-900 flex-1">
          {article ? 'Edit Article' : 'New Article'}
        </h1>
        <Button onClick={handleSubmit} disabled={saveMutation.isPending} size="sm">
          <Save className="w-4 h-4 mr-2" />
          Save
        </Button>
      </header>

      <form onSubmit={handleSubmit} className="p-4 space-y-4 max-w-2xl mx-auto">
        {/* Title */}
        <div className="space-y-2">
          <Label>Title</Label>
          <Input
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="How to book a service"
            required
          />
        </div>

        {/* Category */}
        <div className="space-y-2">
          <Label>Category</Label>
          <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Booking & Scheduling">Booking & Scheduling</SelectItem>
              <SelectItem value="Billing & Payments">Billing & Payments</SelectItem>
              <SelectItem value="Account Management">Account Management</SelectItem>
              <SelectItem value="Services & Care">Services & Care</SelectItem>
              <SelectItem value="Worker Guidelines">Worker Guidelines</SelectItem>
              <SelectItem value="Safety & Compliance">Safety & Compliance</SelectItem>
              <SelectItem value="Troubleshooting">Troubleshooting</SelectItem>
              <SelectItem value="FAQ">FAQ</SelectItem>
              <SelectItem value="Policies">Policies</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Portal */}
        <div className="space-y-2">
          <Label>Applies To</Label>
          <Select value={formData.portal} onValueChange={(value) => setFormData({ ...formData, portal: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Portals</SelectItem>
              <SelectItem value="customer">Customer Only</SelectItem>
              <SelectItem value="worker">Worker Only</SelectItem>
              <SelectItem value="admin">Admin Only</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Content */}
        <div className="space-y-2">
          <Label>Content</Label>
          <Textarea
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            placeholder="Write the full article content here..."
            rows={12}
            required
          />
        </div>

        {/* Keywords */}
        <div className="space-y-2">
          <Label>Keywords (comma separated)</Label>
          <Input
            value={formData.keywords}
            onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
            placeholder="booking, schedule, appointment, service"
          />
          <p className="text-xs text-gray-500">Used for search and AI matching</p>
        </div>

        {/* Published */}
        <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
          <div>
            <Label>Published</Label>
            <p className="text-xs text-gray-500">Make article visible in chat</p>
          </div>
          <Switch
            checked={formData.is_published}
            onCheckedChange={(checked) => setFormData({ ...formData, is_published: checked })}
          />
        </div>
      </form>
    </div>
  );
}